<template>
  <div class="container" style="width: auto;">
    <locale-switcher v-show="false"></locale-switcher>
    <router-view></router-view>
    <navigation></navigation> 
  </div> 
</template>

<script>
import { useI18n } from 'vue-i18n';
import LocaleSwitcher from './components/LocaleSwitcher.vue'
import Navigation from './components/Navigation.vue';

export default {
  name: 'App',
  components: {
    LocaleSwitcher,
    Navigation
  },
  setup() {
    const { t } = useI18n({
        inheritLocale: true,
        useScope: "global"
    });
    return { t };
  }
}
</script>

<style>
body {
  margin:0;
}
#app {
  font-family: 'Open Sans', sans-serif;
  color:#3c3c3c;
}
* {
  transition: all .5s ease 0s;
}
</style>