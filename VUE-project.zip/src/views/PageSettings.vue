<template>
    <b>COMING SOON...</b>
    <locale-switcher></locale-switcher>
</template>

<script>
import LocaleSwitcher from '../components/LocaleSwitcher.vue';

export default {
    components: {
        LocaleSwitcher
    }
}
</script>