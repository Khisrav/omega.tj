<template>
  <greeting
    :showGreetingWord="false"
    :studentName="studentInfo.name"
    :studentSurname="studentInfo.surname"
    :grade="studentInfo.grade"
  ></greeting>
</template>

<script>
import Greeting from '@/components/Greeting.vue';

export default {
  components: {
    Greeting
  },
  created() {
    this.studentInfo = this.getStudentInfo();
    console.log(this.studentInfo);
  },
  data() {
    return {
      studentInfo: null
    }
  },
  methods: {
    async getStudentInfo() {
      try {
        let res = await fetch('student.json');
        let data = await res.json();
        // console.log(this.studentInfo, data);
        return data;
      }
      catch (error) {
        console.error('Error fetching data:', error);
        return null;
      }
    }
  }
}
</script>

<style>
</style>